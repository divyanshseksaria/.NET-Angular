--View Seeded Data

select * from Users
select * from PropertyTypes
select * from FurnishingTypes
select * from Cities
select * from Properties