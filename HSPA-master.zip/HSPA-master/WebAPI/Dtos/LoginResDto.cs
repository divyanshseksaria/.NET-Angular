namespace WebAPI.Dtos
{
    public class LoginResDto
    {
        public string UserName { get; set; }
        public string Token { get; set; }
    }
}