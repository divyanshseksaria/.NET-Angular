namespace WebAPI.Dtos
{
    public class CityUpdateDto
    {
        public string Name { get; set; }
    }
}