import { IPropertyBase } from './ipropertybase';

export interface IProperty extends IPropertyBase {
    Description: string;
}
