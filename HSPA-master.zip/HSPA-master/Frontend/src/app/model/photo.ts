export interface Photo {
    imageUrl: string;
    publicId: string;
    isPrimary: boolean;
}
