export interface Ikeyvaluepair {
    id: number;
    name: string;
}
