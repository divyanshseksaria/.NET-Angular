export const environment = {
    production: true,
    baseUrl: 'https://housing.azurewebsites.net/api'
};
