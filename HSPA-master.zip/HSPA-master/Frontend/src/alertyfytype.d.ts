declare module 'alertifyjs';
